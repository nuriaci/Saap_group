# archivo: vulnerado.py

print("Has sido vulnerado")
