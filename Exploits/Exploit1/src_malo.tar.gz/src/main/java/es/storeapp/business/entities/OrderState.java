package es.storeapp.business.entities;

public enum OrderState {
    PENDING, COMPLETED, CANCELLED 
}
